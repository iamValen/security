#### We are surrounded by hardware devices
- Many do not have an accessible operating system
#### These devices are potential security issues
- A perfect entry point for an attack
#### Everything is connecting to the network
- Light bulbs, garage doors, refrigerators, door locks...
- IoT is everywhere
#### The security landscape has grown
- Time to change your approach


## Firmware
#### The software inside of the hardware
- The operating system of the hardware device
#### Vendors are the only ones who can fix their hardware
- Assuming they know about the problem
- And care about fixing it
#### Trane Comfortlink II thermostats
- Control the temperature from your phone
- Trane notified of three vulnerabilities in April 2014
- Two patched in April 2015, one in January 2016


## End-of-life
#### End of Live (EOL)
- Manufacturer stops selling a product
- May continue supporting the product
- Important for security patches and updates
#### End of service life (EOSL)
- Manufacturer stops selling a product
- Support is no longer available for the product
- No ongoing security patches or updates
- May have a premium-cost support option
#### Technology EOSL is a significant concern
- Security patches are part of normal operation


## Legacy platforms
#### Some devices remain installed for a long time
- Perhaps too long
#### Legacy devices
- Older operating systems, applications, middleware
#### May be running end-of-life software
- The risk needs to be compared to the return
#### May require additional security protections
- Additional firewall rules
- IPS signatures for older operating systems